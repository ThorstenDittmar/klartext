# Spec: TimeSlice und Zeitscheiben-Verkettung

**Datum:** 2026-06-03
**Status:** Freigegeben
**Scope:** TimeSlice als eigenständiges Objekt, Verkettung über
CausalModelFederation, Verzweigung in alternative Folge-Scheiben.

---

## Grundprinzip

Eine Zeitscheibe ist ein `CausalModel` dessen temporaler Geltungsbereich
auf einen bestimmten Zeitraum gesetzt ist. `TimeSlice` ist ein
eigenständiges Objekt — keine bloßen zwei Zahlen — und steckt im `Scope`
des `CausalModel`.

Zeitscheiben sind diskret und überlappen sich nicht innerhalb desselben
Modellpfads.

---

## Klassendefinition

```python
@dataclass
class TimeSlice:
    """Eigenständiges Zeitobjekt. Kein CausalComponent.
    Lebt im Scope.temporal eines CausalModel."""
    start: date
    end: date
    identifier: str = field(default="")

    def __post_init__(self):
        if not self.identifier:
            self.identifier = f"{self.start.year}-{self.end.year}"
```

`Scope.temporal` verweist auf eine `TimeSlice`-Instanz:

```python
@dataclass
class Scope:
    temporal:     TimeSlice | None = None
    spatial:      SpatialRef | None = None
    disciplinary: DisciplineRef | None = None
```

---

## Pre- und Postconditions: Verantwortung liegt am CausalModel

Preconditions und Postconditions liegen am `CausalModel`, nicht an der
`TimeSlice`. Begründung: Conditions referenzieren Slots — Slots sind
Modellelemente. Eine TimeSlice kennt keine Slots. Das Kontextualisierungs-
prinzip bleibt gewahrt (alle semantischen Operationen top-down).

```python
@dataclass
class CausalModel(CausalComposite):
    scope: Scope
    preconditions: list[Precondition] = field(default_factory=list)
    postconditions: list[Postcondition] = field(default_factory=list)
    ...
```

Die TimeSlice ist ein reines Zeitobjekt ohne Modellkenntnis.

---

## Verzweigung: Mehrere Varianten einer Folge-Scheibe

Auf eine Zeitscheibe können mehrere alternative Folge-Scheiben folgen.
Alle Varianten müssen mit den Postconditions der Vorgänger-Scheibe
kompatibel sein — sie können diese konsumieren oder neutral lassen.

Beispiel:

```
CausalModelFederation
  ├── CausalModel A  (2020–2030)
  │     postconditions: [CO2=HOCH, Temp=+1.5°C]
  │
  ├── CausalModel B  (2030–2040, Variante: Mitigation)
  │     preconditions:  [CO2=HOCH]        ← konsumiert A.postcondition
  │     postconditions: [CO2=SINKEND, ...]
  │
  └── CausalModel C  (2030–2040, Variante: Business-as-usual)
        preconditions:  [CO2=HOCH]        ← konsumiert A.postcondition
        postconditions: [CO2=HOCH, Temp=+2.5°C]
```

Varianten können ein gemeinsames `CausalMixin` einbinden das das
geteilte Fundament beschreibt, während die Unterschiede im jeweiligen
Modell liegen.

---

## Prüfverantwortung: CausalModelFederation

Die `CausalModelFederation` kennt die Verzweigungsstruktur und ist
verantwortlich für die Übergangsprüfung:

- Alle Modelle die auf Scheibe N folgen müssen dessen Postconditions
  konsumieren oder verträglich lassen (kein Konflikt).
- Propagations-Tracking über mehrere Scheiben hinweg.
- `get_active_postconditions(at_model)` aggregiert alle propagierenden
  Postconditions die zu einem Modell in der Kette aktiv sind.

```python
class CausalModelFederation(CausalComposite):
    def get_successors(self, model: CausalModel) -> list[CausalModel]:
        """Returns all direct successor slices of model."""
        ...

    def validate_transition(
        self,
        predecessor: CausalModel,
        successor: CausalModel
    ) -> list[ConditionConflict]:
        """Checks Postcondition/Precondition compatibility at the boundary."""
        ...

    def get_active_postconditions(
        self,
        at_model: CausalModel
    ) -> list[Postcondition]:
        """All Postconditions propagating into at_model from earlier slices."""
        ...
```

---

## Übergangsregeln (Referenz auf Precondition/Postcondition Spec)

Siehe `2026-06-03-precondition-postcondition.md` für die vollständigen
Übergangsregeln (konsumiert / konflikt / propagiert).

---

## Offene Punkte

| # | Thema |
|---|---|
| T-09 | Veränderungen (steigend/sinkend) innerhalb einer Zeitscheibe |
| T-18 | Scope-Verhalten beim `add()` — betrifft auch TimeSlice-Kompatibilität |
| T-21 | Versionierungsmechanik: wie verhält sich Versionierung bei verzweigten Zeitscheiben? |
