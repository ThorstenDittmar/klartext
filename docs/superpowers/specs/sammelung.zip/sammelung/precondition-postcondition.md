{\rtf1\ansi\ansicpg1252\cocoartf2867
\cocoatextscaling0\cocoaplatform0{\fonttbl\f0\fswiss\fcharset0 Helvetica;}
{\colortbl;\red255\green255\blue255;}
{\*\expandedcolortbl;;}
\paperw11900\paperh16840\margl1440\margr1440\vieww11520\viewh8400\viewkind0
\pard\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\pardirnatural\partightenfactor0

\f0\fs24 \cf0 # Spec: Precondition und Postcondition\
\
**Datum:** 2026-06-03  \
**Status:** Freigegeben  \
**Scope:** Koppelungsprotokoll zwischen Zeitscheiben im Wirkgef\'fcge.\
Zeitscheiben selbst sind noch nicht vollst\'e4ndig spezifiziert (T-23).\
\
---\
\
## Zweck\
\
Precondition und Postcondition sind das \'dcbergabe-Protokoll an den Grenzen\
zwischen Zeitscheiben. Sie definieren in welchem Zustand ein Slot am Ende\
einer Zeitscheibe \'fcbergeben wird (Postcondition) und in welchem Zustand\
er zu Beginn der n\'e4chsten Scheibe erwartet wird (Precondition).\
\
---\
\
## Klassendefinition\
\
@dataclass\
class Condition:\
    """Abstract base. Not a CausalComponent."""\
    slot: Slot\
    state: Zustand\
    scope: Scope\
\
@dataclass\
class Precondition(Condition):\
    """Expected state at the start of a time slice.\
    Consuming a matching Postcondition terminates its propagation."""\
    pass\
\
@dataclass\
class Postcondition(Condition):\
    """Resulting state at the end of a time slice.\
    Propagates forward until consumed by a matching Precondition."""\
    pass\
\
---\
\
## \'dcbergangsregeln\
\
Fall 1 \'97 Konsumiert: Postcondition N und Precondition N+1, gleicher Slot, kompatibler Zustand \uc0\u8594  \'dcbergang valid, Postcondition endet.\
\
Fall 2 \'97 Konflikt: gleicher Slot, inkompatibler Zustand \uc0\u8594  ConditionConflict (ModelIssue), blockiert.\
\
Fall 3 \'97 Propagiert: keine Precondition f\'fcr diesen Slot in N+1 \uc0\u8594  UI-Hinweis, Postcondition l\'e4uft weiter in N+2, N+3 usw.\
\
---\
\
## Propagationsregel\
\
Eine Postcondition propagiert unbegrenzt vorw\'e4rts. Sie endet nur wenn eine sp\'e4tere Scheibe sie explizit mit einer passenden Precondition konsumiert. Kein Ablaufdatum, keine implizite Beendigung.\
\
---\
\
## Wichtige Abfrage\
\
def get_active_postconditions(self, at_slice: TimeSlice) -> list[Postcondition]:\
    """All Postconditions propagating at this slice \'97 not yet consumed."""\
    ...\
\
---\
\
## Abgrenzung zu source_condition\
\
CausalRelation.source_condition = direkte Ursache (l\'f6st Relation aus).\
Precondition = Kontextbedingung (muss gelten, ist nicht Ursache).\
\
---\
\
## ConditionConflict\
\
ConditionConflict (ModelIssue)\
  status: open \uc0\u8594  acknowledged \u8594  resolved\
  affected_components: [Slot]\
  postcondition: Postcondition\
  precondition: Precondition\
\
Offener ConditionConflict setzt CausalModel.is_complete() = False.\
\
---\
\
## Offene Punkte\
\
T-23: TimeSlice vollst\'e4ndig spezifizieren\
T-09: Ver\'e4nderungen (steigend/sinkend) \'97 h\'e4ngt an Zeitscheiben}