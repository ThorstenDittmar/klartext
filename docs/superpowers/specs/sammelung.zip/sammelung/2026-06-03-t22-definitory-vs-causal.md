# Spec: DefinitoryRelation vs. CausalRelation (T-22)

**Datum:** 2026-06-03
**Status:** Freigegeben
**Scope:** Abgrenzung DefinitoryRelation von CausalRelation mit AXIOMATIC.
Schließt T-22.

---

## Entscheidung: Strukturelle, nicht epistemische Unterscheidung

Die beiden Relationstypen beantworten fundamental verschiedene Fragen:

**DefinitoryRelation** beantwortet: *Was bedeutet dieser Begriff?*
Sie ist atemporal und konzeptbasiert. Sie gilt unabhängig von Zeit,
Ort und Modellzustand. Kein Mechanismus, keine Polarität, keine
Stärke.

**CausalRelation** beantwortet: *Was bewirkt was?*
Sie beschreibt einen gerichteten Wirkzusammenhang mit Mechanismus,
Polarität, Stärke und Unsicherheit. Sie kann AXIOMATIC gesetzt sein —
das bedeutet, der Autor leitet sie nicht weiter her, setzt sie aber
als Kausalaussage.

Der Unterschied ist **nicht epistemisch** (beide können AXIOMATIC sein),
sondern **strukturell**: Definition vs. Wirkzusammenhang.

---

## Abgrenzungsregel

> Wenn der Autor einen Mechanismus benennen kann, ist es eine
> `CausalRelation`. Wenn es eine begriffliche Gleichsetzung ist —
> also eine Aussage darüber was ein Begriff bedeutet — ist es eine
> `DefinitoryRelation`.

Beispiele:

| Aussage | Typ |
|---|---|
| „Ein Treibhausgas ist ein Gas das Infrarotstrahlung absorbiert." | DefinitoryRelation |
| „CO₂-Konzentration hoch bewirkt Temperaturanstieg (Mechanismus: Treibhauseffekt)." | CausalRelation |
| „Wirtschaftswachstum erhöht CO₂-Emissionen (Mechanismus: Industrieproduktion)." | CausalRelation |
| „Wirtschaftswachstum bedeutet per Definition mehr Emissionen." | DefinitoryRelation — aber Verdachtsfall, siehe unten |

---

## Risiko: DefinitoryRelation als Hintertür für versteckte Axiome

Ein Autor könnte eine starke Kausalaussage als `DefinitoryRelation`
tarnen und damit eine Axiom-Entscheidung hinter einer scheinbar
neutralen Definition verstecken.

Dieses Risiko lässt sich nicht vollständig technisch verhindern.
Es wird durch zwei Maßnahmen strukturell unattraktiv gemacht:

### Maßnahme 1 — Systemseitige Warnung

Das System prüft bei jeder `DefinitoryRelation` ob die beteiligten
Slots in `CausalRelationen` als `source_condition` oder `target_effect`
vorkommen. Wenn ja, erzeugt das System eine Warnung:

> „Diese Definition berührt kausale Elemente des Modells. Handelt es
> sich um eine versteckte Kausalannahme?"

Die Warnung blockiert nicht — sie macht den Verdachtsfall sichtbar.

### Maßnahme 2 — Transparenzbericht

Alle `DefinitoryRelationen` werden im Transparenzbericht explizit
aufgeführt und als Definitionen ausgewiesen. Wer eine Kausalaussage
als Definition tarnt, macht das öffentlich sichtbar. Die Community
kann darauf reagieren.

Beide Maßnahmen sind konsistent mit dem Grundprinzip der Plattform:
keine Wahrheitsmaschine, aber maximale Transparenz.

---

## Offene Todos

Keine. T-22 ist geschlossen.
