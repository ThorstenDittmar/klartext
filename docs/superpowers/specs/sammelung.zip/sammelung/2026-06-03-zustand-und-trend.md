# Spec: Zustand und Trend-Slots

**Datum:** 2026-06-03
**Status:** Freigegeben
**Scope:** Semantik von `Zustand.value`, Abgrenzung Messwert-Slot vs.
Trend-Slot, Schließung von T-09.

---

## Entscheidung

T-09 (Veränderungen/steigend/sinkend) ist geschlossen. Keine neuen
Konzepte nötig. Zwei Designentscheidungen lösen das Problem:

1. `Zustand.value` beschreibt einen Wert im deklarierten Zustandsraum
   des Slots. Was ein valider Wert ist, bestimmt der Slot — nicht das
   System.

2. Trend ist ein eigenständiger Slot-Typ. Wer Dynamik modellieren will,
   legt einen expliziten Trend-Slot an. Ein Messwert-Slot mit einem
   Trend-Wert zu beschreiben ist ein Modellierungsfehler.

---

## Zwei Slot-Typen

### Messwert-Slot

Zustandsraum: quantitative oder qualitative Werte.

```
Slot: co2_concentration
  slot_type: physical_quantity
  Zustand.value = 421.0        # korrekt
  Zustand.value = "steigend"   # Modellierungsfehler
```

### Trend-Slot

Zustandsraum: diskret, z.B. {steigend, stabil, sinkend}.

```
Slot: co2_trend
  slot_type: trend
  Zustand.value = "steigend"   # korrekt — eigener Slot
  Zustand.value = 421.0        # Modellierungsfehler
```

---

## Verbindung zwischen Messwert und Trend

Die Beziehung zwischen `co2_concentration` und `co2_trend` ist eine
explizite Modellstruktur — keine implizite Eigenschaft des Zustands:

- **Axiomatic:** Der Autor setzt `co2_trend = steigend` direkt als
  Annahme (`epistemic_status = AXIOMATIC`). Keine Ableitung nötig.

- **Derived:** Der Trend wird aus dem Vergleich zweier Zeitscheiben
  abgeleitet. `derivation_source` verweist auf die Relation oder
  den Zeitscheibenvergleich der diesen Wert erzeugt.

```
co2_trend (Zustand: "steigend")
  epistemic_status = DERIVED
  derivation_source → CausalRelation oder Zeitscheibenvergleich
```

---

## Zwischenschritte innerhalb einer Zeitscheibe

Zeitscheiben haben einen Anfangszustand und einen Endzustand.
Zwischenschritte werden nicht explizit modelliert. Wer einen
Zwischenschritt für relevant hält, legt eine eigene Zeitscheibe an.
Das liegt beim Autor, nicht beim System.

---

## Konsequenz für die Spec (§4 Zustand)

`Zustand.value` beschreibt einen Wert im deklarierten Zustandsraum
eines Slots. Trend-Werte wie `"steigend"` sind nur dann valide, wenn
der Slot explizit ein Trend-Slot ist. Der Zustandsraum eines Slots
muss im Modell deklariert oder aus dem `slot_type` ableitbar sein.

---

## Geschlossene Todos

| # | Thema | Entscheidung |
|---|---|---|
| T-09 | Veränderungen (steigend/sinkend) und Zeitscheiben | Trend = eigenständiger Slot. Zwischenschritte nicht modelliert. |
